<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Paytm
 *
 */
$lang["paytm_merchant_key"]    = "Paytm Merchant Key";
$lang["Paytm_mid_merchant_id"] = "Paytm MID (Merchant ID)";
$lang["Paytm_Integration"]     = "Paytm Integration";
$lang["paytm_confirmation"]    = "Paytm confirmation";
$lang["the_system_will_convert_automatically_from_INR_to_USD_and_add_funds_to_your_blance_when_payment_is_made"] = "The system will convert automatically from INR to USD and add funds to your blance when payment is made";